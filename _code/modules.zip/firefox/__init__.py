# -*- coding: utf-8 -*-
# firefox/__init__.py